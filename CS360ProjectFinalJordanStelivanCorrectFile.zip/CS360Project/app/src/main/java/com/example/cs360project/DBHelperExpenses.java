package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperExpenses extends SQLiteOpenHelper {

    //Expense information Database
    public static final String DBNAME = "Expenses.db";
    //Expense Total Variable
    public Double expenseTotal;

    public DBHelperExpenses (Context context){
        super(context, "Expenses.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase ExpenseDB){
        //Create a table for Expenses
        ExpenseDB.execSQL("create Table Expenses(expense TEXT primary key, Cost Double)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int j){
        MyDB.execSQL("drop Table if exists Expenses");
    }

    //Function for inserting Expense information into Database
    public Boolean insertData(String expense, Double cost){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Enter Expense", expense);
        contentValues.put("Enter Cost", cost);
        long result = MyDB.insert("Expenses", null, contentValues);
        if(result == -1) {
            return false;
        } else{
            return true;
        }
    }

    //Check for the Expense within the DB
    public Boolean checkExpense(String expense){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from Expenses where expense = ?", new String[]
                {expense});
        if(cursor.getCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    //Delete Contents within DB
    public Boolean deleteExpense(String expense){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Expense List where expense = ?", new String[]{expense});
        if(cursor.getCount() > 0){
            long result = DB.delete("Expenses", "name=?", new String[]{expense});
            if(result == -1){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }

    //Update Contents within DB
    public Boolean updateExpense(String expense, Double cost){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Expense", expense);
        contentValues.put("Cost", cost);
        Cursor cursor = DB.rawQuery("Select * from Expenses List where expense = ?", new String[]{expense});
        if(cursor.getCount() > 0){
            long result=DB.update("Expenses", contentValues, "expenses=?", new String[]{expense});
            if(result==-1){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }

    //Returns all Data
    public Cursor getAllExpenseData() {

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor res = DB.rawQuery("Select * from Expenses List", null);
        return res;
    }
}
