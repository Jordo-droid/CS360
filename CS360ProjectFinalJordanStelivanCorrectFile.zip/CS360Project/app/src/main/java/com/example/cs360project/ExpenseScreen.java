package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;


import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

//Class for Expenses Screen
public class ExpenseScreen extends AppCompatActivity {

    //Variables for use in functions below
    ListView expenses;
    EditText editTextCost, editTextExpense;
    Button buttonAdd, buttonDelete, buttonUpdate, buttonHome, buttonRefresh;
    DBHelperExpenses DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expenses_layout);

            //Expense Variables
            expenses = (ListView) findViewById(R.id.textExpenseView);
            buttonAdd = (Button) findViewById(R.id.buttonNewExpense);
            buttonDelete = (Button) findViewById(R.id.buttonDeleteExpense);
            buttonUpdate = (Button) findViewById(R.id.buttonEditExpense);
            buttonHome = (Button) findViewById(R.id.buttonHome);
            buttonRefresh = (Button) findViewById(R.id.buttonRefresh);

            //Variables for work with Database in List View
            DB = new DBHelperExpenses(this);
            ListView expenseView = findViewById(R.id.textExpenseView);


            //Function for Adding a New Expense
            buttonAdd.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                    String expenseName = editTextExpense.getText().toString();
                    Double expenseCost = Double.parseDouble(editTextCost.getText().toString());

                    //Makes certain there are no empty fields when users register
                    if(expenseName.equals("")||expenseCost.equals("")){
                        Toast.makeText(ExpenseScreen.this, "Please Enter all Fields",
                                Toast.LENGTH_SHORT).show();
                    }else{
                        //Checks if user already exists and adds credentials to DB if new user
                        Boolean checkExpense = DB.checkExpense(expenseName);
                        if(checkExpense==false){
                            Boolean insert = DB.insertData(expenseName, expenseCost);
                            Toast.makeText(ExpenseScreen.this, "Entered Successfully",
                                    Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(ExpenseScreen.this, "Expense Already Exists...",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });


            //Function for Deleting Expense List
            buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String expenseName = editTextExpense.getText().toString();

                    //Makes certain there are no empty fields when users register
                    if(expenseName.equals("")){
                        Toast.makeText(ExpenseScreen.this, "Please Enter Expense to Delete",
                                Toast.LENGTH_SHORT).show();
                    }else{
                        //Checks if Expense is in Database and deletes it if it does
                       Boolean checkExpense = DB.checkExpense(expenseName);
                       if(checkExpense==false){
                           Toast.makeText(ExpenseScreen.this, "Expense Does Not Exist",
                                   Toast.LENGTH_SHORT).show();
                       }else{
                          Boolean delete = DB.deleteExpense(expenseName);
                          Toast.makeText(ExpenseScreen.this, "Deleted Successfully",
                                  Toast.LENGTH_SHORT).show();
                       }
                    }
                }
            });

        //Function for Updating Income List item(s)
        buttonUpdate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String expense = editTextExpense.getText().toString();
                Double cost = Double.parseDouble(editTextCost.getText().toString());

                Boolean checkUpdateData = DB.updateExpense(expense, cost);
                if(checkUpdateData == true){
                    Toast.makeText(ExpenseScreen.this, "Entry Added Successfully",
                            Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(ExpenseScreen.this, "Entry Not Added",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Function for returning to Main Screen
        //Function for returning to Main Screen
        buttonHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        //Function to Refresh the table
        buttonRefresh.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //Moves Database data into Array and then Displays it on screen
                ArrayList<String> aList = new ArrayList<>();
                Cursor data = DB.getAllExpenseData();

                if (data.getCount() == 0) {
                    return;
                } else {
                    while (data.moveToNext()) {
                        aList.add(data.getString(1));
                        ListAdapter listAdapter = new ArrayAdapter<>(getApplicationContext(),
                                android.R.layout.simple_list_item_1, aList);
                        expenseView.setAdapter(listAdapter);
                    }
                }
            }
        });

    }

}