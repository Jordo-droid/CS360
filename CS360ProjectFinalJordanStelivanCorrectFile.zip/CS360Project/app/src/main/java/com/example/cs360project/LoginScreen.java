package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import android.os.Bundle;
import android.widget.Toast;

//Class for Login Screen
public class LoginScreen extends AppCompatActivity {

    EditText username, password;
    Button login, register;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);

        //Login Variables
        username = (EditText) findViewById(R.id.editTextUsername);
        password = (EditText) findViewById(R.id.editTextPassword);
        login = (Button) findViewById(R.id.buttonLogin);
        register = (Button) findViewById(R.id.buttonRegister);
        DB = new DBHelper(this);


        //Function for Registering a New User
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //Makes certain there are no empty fields when users register
                if(user.equals("")||pass.equals("")){
                    Toast.makeText(LoginScreen.this, "Please Enter all Fields",
                            Toast.LENGTH_SHORT).show();
                }else{
                    //Checks if user already exists and adds credentials to DB if new user
                    Boolean checkUser = DB.checkUsername(user);
                    if(checkUser==false){
                        Boolean insert = DB.insertData(user, pass);
                        Toast.makeText(LoginScreen.this, "Registered Successfully",
                                Toast.LENGTH_SHORT).show();
                        //Upon Successful Registration, directs user to Main Screen
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginScreen.this, "User Already Exists. Please Login.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        //Function for Existing user Login
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //Makes certain there are no empty fields when users login
                if(user.equals("")||pass.equals("")){
                    Toast.makeText(LoginScreen.this, "Please enter all fields.",
                            Toast.LENGTH_SHORT).show();
                }else{
                    //Checks login credentials with database and moves to main screen upon success
                    Boolean checkUser = DB.checkUsername(user);
                    if(checkUser==true){
                        Toast.makeText(LoginScreen.this, "Sign in Successful",
                                Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginScreen.this, "Invalid Login Information",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

}

