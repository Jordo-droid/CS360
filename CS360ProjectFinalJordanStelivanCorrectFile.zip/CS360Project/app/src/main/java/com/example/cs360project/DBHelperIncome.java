package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperIncome extends SQLiteOpenHelper {

    //Income information Database
    public static final String DBNAME = "Income.db";
    //Income Total Variable
    public Double incomeTotal;

    public DBHelperIncome (Context context){
        super(context, "Income.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase IncomeDB){
        //Create a table for Income
        IncomeDB.execSQL("create Table Income(incomeDate TEXT primary key, Amount Double)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int j){
        MyDB.execSQL("drop Table if exists Income");
    }

    //Function for inserting Income information into Database
    public Boolean insertData(String incomeDate, Double amount){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Enter Date", incomeDate);
        contentValues.put("Enter Cost", amount);
        long result = MyDB.insert("Income", null, contentValues);
        if(result == -1) {
            return false;
        } else{
            return true;
        }
    }

    //Check for the Income within the DB
    public Boolean checkIncome(String incomeDate){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from Income where income = ?", new String[]
                {incomeDate});
        if(cursor.getCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    //Delete Contents within DB
    public Boolean deleteIncome(String incomeDate){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Income List where incomeDate = ?", new String[]{incomeDate});
        if(cursor.getCount() > 0){
            long result = DB.delete("Income", "incomeDate=?", new String[]{incomeDate});
            if(result == -1){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }

    //Update Contents within DB
    public Boolean updateIncome(String incomeDate, Double amount){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Date", incomeDate);
        contentValues.put("Amount", amount);
        Cursor cursor = DB.rawQuery("Select * from Income List where incomeDate = ?", new String[]{incomeDate});
        if(cursor.getCount() > 0){
            long result=DB.update("Income", contentValues, "incomeDate=?", new String[]{incomeDate});
            if(result==-1){
                return false;
            }else{
                    return true;
            }
        }else{
            return false;
        }
    }

    //Returns all Data
    public Cursor getAllIncomeData() {

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor res = DB.rawQuery("Select * from Income List", null);
        return res;
    }
}
