package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;


import android.os.Bundle;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;

//Class for Income Screen
public class IncomeScreen extends AppCompatActivity {

    //Variables for use in functions below
    ListView income;
    EditText editDate, editAmount;
    Button buttonAdd, buttonDelete, buttonUpdate, buttonHome, buttonRefresh;
    DBHelperIncome DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.income_layout);

        //Income Variables
        income = (ListView) findViewById(R.id.textIncomeView);
        buttonAdd = (Button) findViewById(R.id.buttonDeleteIncome);
        buttonDelete = (Button) findViewById(R.id.buttonDeleteIncome);
        buttonUpdate = (Button) findViewById(R.id.buttonEditIncome);
        buttonHome = (Button) findViewById(R.id.buttonHome);
        buttonRefresh = (Button) findViewById(R.id.buttonRefresh);

        //Variables for work with Database in List View
        DB = new DBHelperIncome(this);
        ListView incomeView = findViewById(R.id.textIncomeView);


        //Function for Adding a New Income
        buttonAdd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String incomeDate = editAmount.getText().toString();
                Double incomeAmount = Double.parseDouble(editDate.getText().toString());

                //Makes certain there are no empty fields when users register
                if(incomeDate.equals("")||incomeAmount.equals("")){
                    Toast.makeText(IncomeScreen.this, "Please Enter all Fields",
                            Toast.LENGTH_SHORT).show();
                }else{
                    //Checks if user already exists and adds credentials to DB if new user
                    Boolean checkIncome = DB.checkIncome(incomeDate);
                    if(checkIncome==false){
                        Boolean insert = DB.insertData(incomeDate, incomeAmount);
                        Toast.makeText(IncomeScreen.this, "Entered Successfully",
                                Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(IncomeScreen.this, "Income Already Exists...",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        //Function for Deleting Income List
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String incomeDate = editAmount.getText().toString();

                //Makes certain there are no empty fields when users register
                if(incomeDate.equals("")){
                    Toast.makeText(IncomeScreen.this, "Please Date Entry to Delete",
                            Toast.LENGTH_SHORT).show();
                }else{
                    //Checks if Income is in Database and deletes it if it does
                    Boolean checkIncome = DB.checkIncome(incomeDate);
                    if(checkIncome==false){
                        Toast.makeText(IncomeScreen.this, "Income Does Not Exist",
                                Toast.LENGTH_SHORT).show();
                    }else{
                        Boolean delete = DB.deleteIncome(incomeDate);
                        Toast.makeText(IncomeScreen.this, "Deleted Successfully",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //Function for Updating Income List item(s)
        buttonUpdate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String incomeDate = editDate.getText().toString();
                Double incomeAmount = Double.parseDouble(editAmount.getText().toString());

                Boolean checkUpdateData = DB.updateIncome(incomeDate, incomeAmount);
                if(checkUpdateData == true){
                    Toast.makeText(IncomeScreen.this, "Entry Added Successfully",
                            Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(IncomeScreen.this, "Entry Not Added",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Function for returning to Main Screen
        buttonHome.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        //Function to Refresh the table
        buttonRefresh.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //Moves Database data into Array and then Displays it on screen
                ArrayList<String> aList = new ArrayList<>();
                Cursor data = DB.getAllIncomeData();

                if (data.getCount() == 0) {
                    return;
                } else {
                    while (data.moveToNext()) {
                        aList.add(data.getString(1));
                        ListAdapter listAdapter = new ArrayAdapter<>(getApplicationContext(),
                                android.R.layout.simple_list_item_1, aList);
                        incomeView.setAdapter(listAdapter);
                    }
                }
            }
        });


    }

}