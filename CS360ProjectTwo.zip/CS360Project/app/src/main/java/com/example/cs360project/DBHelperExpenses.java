package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperExpenses extends SQLiteOpenHelper {

    //Expense information Database
    public static final String DBNAME = "Expenses.db";

    public DBHelperExpenses (Context context){
        super(context, "Expenses.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase ExpenseDB){
        //Create a table for Expenses
        ExpenseDB.execSQL("create Table Expenses(String TEXT primary key, Cost DOUBLE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int j){
        MyDB.execSQL("drop Table if exists Expenses");
    }

    //Function for inserting Expense information into Database
    public Boolean insertData(String expense, Double cost){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Enter Expense", expense);
        contentValues.put("Enter Cost", cost);
        long result = MyDB.insert("Expenses", null, contentValues);
        if(result == -1) {
            return false;
        } else{
            return true;
        }
    }
}
